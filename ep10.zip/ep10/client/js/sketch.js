var socket;
var playerNum1;


// everything about the (loading) before the game starts
function preload() {
    // write code
}

// this is the firs thing that is called when the game is started, and it only happens once (Setup)
function setup() {
    socket = io();
    socket.emit("message", "Hello, Im devlogerio connecting to your server");
    socket.on('messageFromServer', function(data) {
        console.log(data);
    })
    // write code
    playerNum1 = new Player('Devlogerio', 0, 0);

    createCanvas(windowWidth, windowHeight);
}

// this is called alot of times per second (FPS, frame per second)
function draw() {
    background(51, 51, 255); // it gets a hex/rgb color
    translate(width/2 - playerNum1.location.x, height/2 - playerNum1.location.y);
    
    fill(51);
    rect(0, 0, 600, 600);

    playerNum1.update();
    playerNum1.draw();
}

// The player object constructor
var Player = function(name, x, y) {
    this.name = name;
    this.location = createVector(x, y);
    this.force = createVector(0, 0);
    this.acceleration = createVector(0, 0);
    this.speed = createVector(0, 0);
    this.mouseMaxForce = 0.1;
    this.maxAcceleration = 3;
    this.maxSpeed = 3;
    this.mass = 1;

    this.getMouseForce = function() {
        var force = createVector(mouseX - windowWidth/2, mouseY - windowHeight/2);
        force.limit(this.mouseMaxForce);
        force.div(this.mass);
        return force;
    }

    // amountOfForce is a vector
    this.addForce = function(amountOfForce) {
        var force = amountOfForce;
        this.force = force;
    }

    this.accelerate = function() {
        this.acceleration.add(this.force);
        this.acceleration.limit(this.maxAcceleration);
    }

    this.speedUp = function() {
        this.speed.add(this.acceleration);
        this.speed.limit(this.maxSpeed);
    }

    this.move = function() {
        this.location.add(this.speed);
    }

    this.zeroOutAcceleration = function() {
        this.acceleration = createVector(0, 0);
    }

    this.update = function() {
        this.addForce(this.getMouseForce());
        this.accelerate();
        this.speedUp();
        this.move();
        this.zeroOutAcceleration();
    }

    this.draw = function() {
        var angle = atan2(mouseY - windowHeight/2, mouseX - windowWidth/2);
    
        push();
        translate(this.location.x, this.location.y);
        rotate(angle);
        fill(255, 0, 0);
        beginShape();
        vertex(30 + 30, 0);
        vertex(30 + -70, 30);
        vertex(30 + -45, 0);
        vertex(30 + -70, -30);
        endShape(CLOSE);
        pop();
        
        // this.speedX = cos(angle) * 3; // cosine is never gonna get more than 1
        // this.speedY = sin(angle) * 3;

        // if(this.speedX > 3) {
        //     this.speedX = 3;
        // }
    
        // if(this.speedY > 3) {
        //     this.speedY = 3;
        // }
    
        // this.x += this.speedX;
        // this.y += this.speedY;
    }
    
    return this;
}


