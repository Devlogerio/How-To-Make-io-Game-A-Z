
var path = require("path"); // this will find the path of any folder of our game
var http = require("http"); // for starting an online server
// npm install libraryName
var express = require("express"); // sending and recieving files // we need to download it
var socketIO = require("socket.io"); // sending and recieving information/data // we need to download it

var publicPath = path.join(__dirname, '../client'); // it simply adds two paths together ("E:/") joins ("class/client") = ("E:/class/client") 
var port = process.env.PORT || 2000; // this is the port that our server is using on a computer
var app = express(); // we initialize express library and we call it app
var server = http.createServer(app); // we create the server and the file responsibility is on app(express library)
var io = socketIO(server); // connecting the socket.io library to our server
app.use(express.static(publicPath)); // this sends client folder to each client who connects

// we run the server and we make sure it is started on the PORT
server.listen(port, function() {
    console.log("Server successfully runned on port " + port); // this will log something to the therminal
});

// the clients information will be stored in socket parameter
io.on('connection', function(socket) {
    console.log('someone conencted, Id: ' + socket.id);
    
})

