

// everything about the (loading) before the game starts
function preload() {
    // write code
}

// this is the firs thing that is called when the game is started, and it only happens once (Setup)
function setup() {
    // write code
    console.log("Hello world");
}

// this is called alot of times per second (FPS, frame per second)
function draw() {
    // write code
}
