
// int(5, 6, 1, 2, 3), float/double(3.3, 3.5), string("devlogerio"), Object, Array
var a = 5;

var myObject = {
    x: 10,
    y: 5,
    name: "Devlogerio",
    height: 20
};

// Arrays in javascript are zero indexed
//               0    1    2     3      4    5  6
var myArray1 = ["s", "b", "4", "This", "as", 2, 20]; // each data in array is called Element and each element has its own index

// camel case naming
function printSometingForMe(data) { // the input is called parameter
    console.log(data);
}

// same as normal function but the order of calling does matter
var printSomethingElseForMe = function(data) {
    console.log(data);
}

// everything about the (loading) before the game starts
function preload() {
    // write code
}

// this is the firs thing that is called when the game is started, and it only happens once (Setup)
function setup() {
    // write code
    printSometingForMe("Hello World"); // we give it an argument as the parameter input
    printSomethingElseForMe(myObject.name);
    printSomethingElseForMe(myArray1[3]);
}

// this is called alot of times per second (FPS, frame per second)
function draw() {
    // write code
}
