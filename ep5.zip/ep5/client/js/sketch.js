var socket;


// everything about the (loading) before the game starts
function preload() {
    // write code
}

// this is the firs thing that is called when the game is started, and it only happens once (Setup)
function setup() {
    socket = io();
    socket.emit("message", "Hello, Im devlogerio connecting to your server");
    socket.on('messageFromServer', function(data) {
        console.log(data);
    })
    // write code
}

// this is called alot of times per second (FPS, frame per second)
function draw() {
    // write code
}
