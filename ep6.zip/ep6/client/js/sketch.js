var socket;


// everything about the (loading) before the game starts
function preload() {
    // write code
}

// this is the firs thing that is called when the game is started, and it only happens once (Setup)
function setup() {
    socket = io();
    socket.emit("message", "Hello, Im devlogerio connecting to your server");
    socket.on('messageFromServer', function(data) {
        console.log(data);
    })
    // write code

    createCanvas(windowWidth, windowHeight);
}


var x = 0;
var y = 50;

// this is called alot of times per second (FPS, frame per second)
function draw() {
    background(51, 51, 255); // it gets a hex/rgb color
    // x, y, w, h
    // rectMode(CENTER);
    // rect(x, y, 55, 55);
    // triangle(x, y, x + 20, y, x + 10, y + 20); // triangle(x1, y1, x2, y2, x3, y3)
    fill(255, 0, 0);
    beginShape();
    // vertex(0, 0);
    // vertex(-30, 90);
    // vertex(0, 75);
    // vertex(30, 90);
    vertex(x + 0, y + 0);
    vertex(x + (-30), y + 90);
    vertex(x + 0, y + 75);
    vertex(x + 30, y + 90);
    endShape(CLOSE);


    x += 1; // x++

}
