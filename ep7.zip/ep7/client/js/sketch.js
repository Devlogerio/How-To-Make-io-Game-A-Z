var socket;


// everything about the (loading) before the game starts
function preload() {
    // write code
}

// this is the firs thing that is called when the game is started, and it only happens once (Setup)
function setup() {
    socket = io();
    socket.emit("message", "Hello, Im devlogerio connecting to your server");
    socket.on('messageFromServer', function(data) {
        console.log(data);
    })
    // write code

    createCanvas(windowWidth, windowHeight);
}


var x = 0;
var y = 50;
var speedX = 0;
var speedY = 0;

// this is called alot of times per second (FPS, frame per second)
function draw() {
    background(51, 51, 255); // it gets a hex/rgb color

    translate(width/2 - x, height/2 - y);

    fill(51);
    rect(0, 0, 600, 600);

    fill(255, 0, 0);
    beginShape();
    vertex(x + 0, y + 0);
    vertex(x + (-30), y + 90);
    vertex(x + 0, y + 75);
    vertex(x + 30, y + 90);
    endShape(CLOSE);


    x += speedX; // x++
    y += speedY; // y++
}

function keyPressed() {
    if(key === "w") { // == === && ||
        speedY = -5;
    }
    if(key === "s") { // == === && ||
        speedY = 5;
    }
    if(key === "a") { // == === && ||
        speedX = -5;
    }
    if(key === "d") { // == === && ||
        speedX = 5;
    }
}

function keyReleased() {
    if(key === "w") { // == === && ||
        speedY = 0;
    }
    if(key === "s") { // == === && ||
        speedY = 0;
    }
    if(key === "a") { // == === && ||
        speedX = 0;
    }
    if(key === "d") { // == === && ||
        speedX = 0;
    }
  return false;
}

