var socket;
var playerNum1;
var playerNum2;


// everything about the (loading) before the game starts
function preload() {
    // write code
}

// this is the firs thing that is called when the game is started, and it only happens once (Setup)
function setup() {
    socket = io();
    socket.emit("message", "Hello, Im devlogerio connecting to your server");
    socket.on('messageFromServer', function(data) {
        console.log(data);
    })
    // write code
    playerNum1 = new Player('Devlogerio', 0, 50);
    playerNum2 = new Player('Devlogerio', 50, 100);

    createCanvas(windowWidth, windowHeight);
}

// this is called alot of times per second (FPS, frame per second)
function draw() {
    background(51, 51, 255); // it gets a hex/rgb color
    translate(width/2 - playerNum1.x, height/2 - playerNum1.y);
    
    fill(51);
    rect(0, 0, 600, 600);

    playerNum1.draw();
    playerNum2.draw();
}

function keyPressed() {
    if(key === "w") { // == === && ||
        playerNum1.speedY = -5;
    }
    if(key === "s") { // == === && ||
        playerNum1.speedY = 5;
    }
    if(key === "a") { // == === && ||
        playerNum1.speedX = -5;
    }
    if(key === "d") { // == === && ||
        playerNum1.speedX = 5;
    }
}

function keyReleased() {
    if(key === "w") { // == === && ||
        playerNum1.speedY = 0;
    }
    if(key === "s") { // == === && ||
        playerNum1.speedY = 0;
    }
    if(key === "a") { // == === && ||
        playerNum1.speedX = 0;
    }
    if(key === "d") { // == === && ||
        playerNum1.speedX = 0;
    }
  return false;
}

// The player object constructor
var Player = function(name, x, y) {
    this.name = name;
    this.x = x;
    this.y = y;
    this.speedX = 0;
    this.speedY = 0;

    this.draw = function() {
    
        fill(255, 0, 0);
        beginShape();
        vertex(this.x + 0, this.y + 0);
        vertex(this.x + (-30), this.y + 90);
        vertex(this.x + 0, this.y + 75);
        vertex(this.x + 30, this.y + 90);
        endShape(CLOSE);
    
    
        this.x += this.speedX;
        this.y += this.speedY;
    }
    
    return this;
}


