var socket;
var playerNum1;


// everything about the (loading) before the game starts
function preload() {
    // write code
}

// this is the firs thing that is called when the game is started, and it only happens once (Setup)
function setup() {
    socket = io();
    socket.emit("message", "Hello, Im devlogerio connecting to your server");
    socket.on('messageFromServer', function(data) {
        console.log(data);
    })
    // write code
    playerNum1 = new Player('Devlogerio', 0, 0);

    createCanvas(windowWidth, windowHeight);
}

// this is called alot of times per second (FPS, frame per second)
function draw() {
    background(51, 51, 255); // it gets a hex/rgb color
    translate(width/2 - playerNum1.x, height/2 - playerNum1.y);
    
    fill(51);
    rect(0, 0, 600, 600);

    playerNum1.draw();
}

// function keyPressed() {
//     if(key === "w") { // == === && ||
//         playerNum1.speedY = -5;
//     }
//     if(key === "s") { // == === && ||
//         playerNum1.speedY = 5;
//     }
//     if(key === "a") { // == === && ||
//         playerNum1.speedX = -5;
//     }
//     if(key === "d") { // == === && ||
//         playerNum1.speedX = 5;
//     }
// }

// function keyReleased() {
//     if(key === "w") { // == === && ||
//         playerNum1.speedY = 0;
//     }
//     if(key === "s") { // == === && ||
//         playerNum1.speedY = 0;
//     }
//     if(key === "a") { // == === && ||
//         playerNum1.speedX = 0;
//     }
//     if(key === "d") { // == === && ||
//         playerNum1.speedX = 0;
//     }
//   return false;
// }

// The player object constructor
var Player = function(name, x, y) {
    this.name = name;
    this.x = x;
    this.y = y;
    this.speedX = 0;
    this.speedY = 0;

    this.draw = function() {
        var angle = atan2(mouseY - windowHeight/2, mouseX - windowWidth/2);
    
        push();
        translate(this.x, this.y);
        rotate(angle);
        fill(255, 0, 0);
        beginShape();
        vertex(30 + 30, 0);
        vertex(30 + -70, 30);
        vertex(30 + -45, 0);
        vertex(30 + -70, -30);
        endShape(CLOSE);
        pop();
        
        this.speedX = cos(angle) * 3; // cosine is never gonna get more than 1
        this.speedY = sin(angle) * 3;

        if(this.speedX > 3) {
            this.speedX = 3;
        }
    
        if(this.speedY > 3) {
            this.speedY = 3;
        }
    
        this.x += this.speedX;
        this.y += this.speedY;
    }
    
    return this;
}


